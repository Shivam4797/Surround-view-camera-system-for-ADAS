'''Copyright (c) <2021> <copyright Shivam&Pradyumna>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.'''
import cv2
import numpy as np
import time
t0= time.time()
width, height = 1600,1200
pts1 = np.float32([[216,603], [772,612], [49,975], [928,986]])
pts2 = np.float32([[0,0],[width,0],[0,height], [width, height]])
matrix = cv2.getPerspectiveTransform(pts1,pts2)
#Rear Side View
img1 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/5.jpeg')#Read the images
img2 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/6.jpeg')#Read the images
imgOutput1 = cv2.warpPerspective(img1,matrix,(width,height))
imgOutput2 = cv2.warpPerspective(img2,matrix,(width,height))
cv2.imwrite('images/Rear view/result1.jpg', imgOutput1)
cv2.imwrite('images/Rear view/result2.jpg', imgOutput2)
#Right Side View
img3 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/1.jpeg')#Read the images
img4 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/2.jpeg')#Read the images
imgOutput11 = cv2.warpPerspective(img3,matrix,(width,height))
imgOutput21 = cv2.warpPerspective(img4,matrix,(width,height))
cv2.imwrite('images/Right side view/result11.jpg', imgOutput11)
cv2.imwrite('images/Right side view/result21.jpg', imgOutput21)
#Front Side View
img5 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/3.jpeg')#Read the images
img6 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/4.jpeg')#Read the images
imgOutput12 = cv2.warpPerspective(img5,matrix,(width,height))
imgOutput22 = cv2.warpPerspective(img6,matrix,(width,height))
cv2.imwrite('images/Front side view/result1.jpg', imgOutput12)
cv2.imwrite('images/Front side view/result2.jpg', imgOutput22)
#Left Side View
img7 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/1.jpeg')#Read the images
img8 = cv2.imread('/Users/shivamtodkar/Documents/AI/Input images/2.jpeg')#Read the images
imgOutput13 = cv2.warpPerspective(img7,matrix,(width,height))
imgOutput23 = cv2.warpPerspective(img8,matrix,(width,height))
cv2.imwrite('images/Left side view/result1.jpg', imgOutput1)
cv2.imwrite('images/Left side view/result2.jpg', imgOutput2)

#Read the images from your directo#Read the images from your directory
import cv2
import os
mainfolder = 'images'
myfolder = os.listdir(mainfolder)
img_number = 1
for folder in myfolder:
    path = mainfolder+'/'+folder
    Images = []
    mylist = os.listdir(path)
    for imgN in mylist:
        curimg = cv2.imread(f'{path}/{imgN}')
        curimg = cv2.resize(curimg, (0,0), None, 0.3,0.3)
        Images.append(curimg)
    stitcher = cv2.Stitcher.create()
    (status,result) = stitcher.stitch(Images)
    if (status == cv2.STITCHER_OK):
        cv2.imwrite('/Users/shivamtodkar/Documents/AI/Img_stitch/imgstitch' + str(img_number)+ '.jpg',result)
        img_number+=1
    else:
        print('Image Stitching Unsuccesfull')
from PIL import Image, ImageDraw, ImageFilter

im1 = Image.open('/Users/shivamtodkar/Downloads/Presentation1_1.jpg')
im2 = Image.open('/Users/shivamtodkar/Documents/AI/Img_stitch/imgstitch0.jpg')
im3 = Image.open('/Users/shivamtodkar/Documents/AI/Img_stitch/imgstitch2.jpg')
im4 = Image.open('/Users/shivamtodkar/Documents/AI/Img_stitch/imgstitch3.jpg')
im5 = Image.open('/Users/shivamtodkar/Documents/AI/Img_stitch/imgstitch1.jpg')
back_im = im1.copy()
back_im.paste(im2, (200, 350))
back_im.paste(im3, (1050, 850))
back_im.paste(im4, (1050, 200))
back_im.paste(im5.rotate(270), (1950, 600))
back_im.save('Output3.jpg', quality=95)
t1 = time.time() - t0
print("Time elapsed: ", t1)